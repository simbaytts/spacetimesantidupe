package ru.spacestudio.spacetridentdupefix;

import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.plugin.java.JavaPlugin;

public class SpaceTridentDupeFix extends JavaPlugin implements Listener {

    @Override
    public void onEnable() {
        // Регистрируем слушатель событий
        getServer().getPluginManager().registerEvents(this, this);
    }

    // Блокировка выполнения команд, если игрок держит трезубец в руке
    @EventHandler
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        Player player = event.getPlayer();

        // Проверяем, держит ли игрок трезубец в основной руке
        if (player.getInventory().getItemInMainHand().getType() == Material.TRIDENT) {
            event.setCancelled(true); // Отмена выполнения команды
        }
    }
}